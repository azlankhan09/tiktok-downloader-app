# TikTok Downloader — Android App

**Made by Azlan Khan**

Android app for the [TikTok Downloader website](https://tiktok-downloader-53jh7m6ytcsuxurdcivppo.streamlit.app/).
Download public TikTok videos without watermark — free, no sign-up needed.

- Package: `com.azlankhan.tiktokdownloader`
- Version: `1.0.0+1` · Min SDK 21 (Android 5.0+)

## What it does

A thin native shell around the live downloader website:

- **Splash screen** with app branding
- **WebView** running the downloader site (paste link → preview → download)
- **Pull-to-refresh** + app-bar reload button
- **Back button** walks WebView history before exiting
- **Real downloads**: videos are saved into the phone's **Downloads** folder
  (via Android MediaStore on Android 10+, classic storage on older versions),
  with an in-app progress bar and a "Download complete" message
- **WhatsApp/external links** (`wa.me`, `mailto:`, `tel:`) open in the
  external browser instead of inside the app
- **About dialog** (menu → About) with the "Made by Azlan Khan" credit

## Build it

Requirements: [Flutter SDK](https://docs.flutter.dev/get-started/install)
(stable), Android SDK with platform 35 + build-tools, Java 17.

```bash
cd tiktok-downloader-app
flutter pub get
flutter analyze        # must report no issues
flutter build apk --debug
```

The debug APK lands at:
`build/app/outputs/flutter-apk/app-debug.apk` — install it directly on any
Android phone (enable "Install unknown apps" for your browser/file manager).

## Release build (for Play Store)

1. **Build the App Bundle** (Google Play wants `.aab`, not `.apk`):
   ```bash
   flutter build appbundle --release
   ```
   Output: `build/app/outputs/bundle/release/app-release.aab`

2. **Sign it with your own keystore.** First create one (keep it safe —
   losing it means you can never update the app):
   ```bash
   keytool -genkey -v -keystore ~/azlan-release-key.jks \
     -keyalg RSA -keysize 2048 -validity 10000 \
     -alias azlan
   ```
   Then tell Gradle about it — create `android/key.properties`:
   ```properties
   storePassword=YOUR_STORE_PASSWORD
   keyPassword=YOUR_KEY_PASSWORD
   keyAlias=azlan
   storeFile=/home/you/azlan-release-key.jks
   ```
   And in `android/app/build.gradle`, replace the release block's
   `signingConfig signingConfigs.debug` with a `release` signing config that
   reads `key.properties` (see the
   [Flutter docs](https://docs.flutter.dev/deployment/android#signing-the-app)).
   **Never commit `key.properties` or the `.jks` file to GitHub.**

3. **Play Store upload — Google's one-time $25 fee.** There is no free way
   around this: a Google Play **Developer account costs a one-time $25**
   (pay.google.com), plus identity verification. After paying, create the app
   in Play Console, upload the signed `.aab`, fill in the store listing,
   content rating and privacy policy, and roll it out.

## Project layout

```
lib/main.dart                 # splash, WebView shell, downloads, about
android/app/src/main/
  kotlin/.../MainActivity.kt  # MediaStore "save to Downloads" channel
  AndroidManifest.xml         # package, permissions, launcher activity
  res/mipmap-*/               # launcher icons (⬇️ on dark)
```

## Notes & limits

- The app needs internet — all downloading/transcoding happens on the
  server (Streamlit Community Cloud free tier). If the site is asleep it
  wakes in ~30–60 seconds on first open.
- TikTok has no official download API; the site relies on yt-dlp, which can
  break if TikTok changes things, and TikTok sometimes blocks datacenter IPs.
- Only TikTok links are accepted (`tiktok.com`, `vt`/`vm.tiktok.com`,
  `tt.site` short links).
