package com.azlankhan.tiktokdownloader

import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream

/**
 * Hosts the Flutter UI and exposes two native helpers over
 * "com.azlankhan.tiktokdownloader/downloads":
 *
 *  - getApiLevel() -> Int
 *  - saveToDownloads(path, fileName, mimeType) -> String (saved uri/path)
 *
 * API 29+: saves through MediaStore (no storage permission needed).
 * API <29: copies into the public Downloads dir (needs WRITE_EXTERNAL_STORAGE,
 * requested from Dart via permission_handler).
 */
class MainActivity : FlutterActivity() {
    private val channelName = "com.azlankhan.tiktokdownloader/downloads"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            channelName,
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "getApiLevel" -> result.success(Build.VERSION.SDK_INT)
                "saveToDownloads" -> {
                    val path = call.argument<String>("path")
                    val fileName =
                        call.argument<String>("fileName") ?: "tiktok_video.mp4"
                    val mimeType =
                        call.argument<String>("mimeType") ?: "video/mp4"
                    if (path.isNullOrEmpty()) {
                        result.error("ARG", "missing file path", null)
                        return@setMethodCallHandler
                    }
                    try {
                        result.success(saveToDownloads(File(path), fileName, mimeType))
                    } catch (e: Exception) {
                        result.error("SAVE_FAILED", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun saveToDownloads(src: File, fileName: String, mimeType: String): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = applicationContext.contentResolver
            val uri = resolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values,
            ) ?: throw IllegalStateException("MediaStore insert failed")
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(src).use { input -> input.copyTo(out) }
            } ?: throw IllegalStateException("Could not open output stream")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri.toString()
        } else {
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS,
            )
            if (!dir.exists()) dir.mkdirs()
            val dest = File(dir, fileName)
            src.copyTo(dest, overwrite = true)
            dest.absolutePath
        }
    }
}
