/// TikTok Downloader — Android app by Azlan Khan.
///
/// A thin native shell around the live downloader website. The website does
/// the heavy lifting (yt-dlp + ffmpeg live on the server); this app adds:
/// splash screen, pull-to-refresh, back-button history, external links
/// opened in the browser, and real file downloads into the Downloads folder.
library;

import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

/// The live downloader website this app wraps.
const String kSiteUrl =
    'https://tiktok-downloader-53jh7m6ytcsuxurdcivppo.streamlit.app/';

/// Native channel to MainActivity (MediaStore download saving + API level).
const String kNativeChannel = 'com.azlankhan.tiktokdownloader/downloads';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TikTokDownloaderApp());
}

class TikTokDownloaderApp extends StatelessWidget {
  const TikTokDownloaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TikTok Downloader',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.redAccent,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

/// Simple branded splash shown while the WebView warms up.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 2200), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomePage()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF111111),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.download_rounded, size: 96, color: Colors.redAccent),
            SizedBox(height: 24),
            Text(
              'TikTok Downloader',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'by Azlan Khan',
              style: TextStyle(fontSize: 14, color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  InAppWebViewController? _webViewController;
  PullToRefreshController? _pullToRefreshController;

  /// null = no active download; otherwise 0.0..1.0 (or -1 = indeterminate).
  double? _downloadProgress;
  String _downloadLabel = '';

  static const MethodChannel _channel = MethodChannel(kNativeChannel);

  @override
  void initState() {
    super.initState();
    _pullToRefreshController = PullToRefreshController(
      settings: PullToRefreshSettings(color: Colors.redAccent),
      onRefresh: () async {
        await _webViewController?.reload();
      },
    );
  }

  Future<void> _openExternal(WebUri uri) async {
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open link')),
      );
    }
  }

  /// Android back button: go back in WebView history, else exit the app.
  Future<void> _onPopInvoked(bool didPop) async {
    if (didPop) return;
    final controller = _webViewController;
    if (controller != null && await controller.canGoBack()) {
      await controller.goBack();
    } else if (mounted) {
      // Nothing to go back to — close the app.
      SystemNavigator.pop();
    }
  }

  void _showAbout() {
    showAboutDialog(
      context: context,
      applicationName: 'TikTok Downloader',
      applicationVersion: '1.0.0',
      applicationLegalese: 'Made by Azlan Khan',
      children: const [
        SizedBox(height: 12),
        Text('Download public TikTok videos without watermark — free.'),
        SizedBox(height: 8),
        Text('Want any website made? Contact me on WhatsApp: +92 3474421152'),
      ],
    );
  }

  // ------------------------------------------------------------------
  // Downloads
  // ------------------------------------------------------------------

  String _fileNameFrom(WebUri uri, String? contentDisposition) {
    // 1) Content-Disposition: attachment; filename="..."
    if (contentDisposition != null) {
      final match = RegExp(r'filename\*?=(?:UTF-8'' )?["]?([^";]+)["]?')
          .firstMatch(contentDisposition);
      if (match != null) {
        final name = Uri.decodeComponent(match.group(1)!.trim());
        if (name.isNotEmpty) return _sanitizeFileName(name);
      }
    }
    // 2) Last path segment of the URL (Streamlit media URLs carry the name).
    final seg = uri.pathSegments.isNotEmpty ? uri.pathSegments.last : '';
    if (seg.isNotEmpty && seg.contains('.')) {
      return _sanitizeFileName(Uri.decodeComponent(seg));
    }
    // 3) Fallback.
    return 'tiktok_video_${DateTime.now().millisecondsSinceEpoch}.mp4';
  }

  String _sanitizeFileName(String name) =>
      name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');

  /// Storage permission is only needed on Android < 10 (API 29); newer
  /// versions save through MediaStore, which needs no permission.
  Future<bool> _ensureStoragePermission() async {
    int apiLevel = 29;
    try {
      final level = await _channel.invokeMethod<int>('getApiLevel');
      if (level != null) apiLevel = level;
    } on PlatformException {
      // If the channel fails, fall back to requesting permission.
      apiLevel = 0;
    }
    if (apiLevel >= 29) return true;
    final status = await Permission.storage.request();
    return status.isGranted;
  }

  Future<void> _downloadFile({
    required WebUri uri,
    required String? mimeType,
    required String? userAgent,
    required String? contentDisposition,
  }) async {
    final fileName = _fileNameFrom(uri, contentDisposition);
    setState(() {
      _downloadProgress = -1; // indeterminate until we know the size
      _downloadLabel = fileName;
    });

    try {
      if (!await _ensureStoragePermission()) {
        throw const _UserVisibleError('Storage permission denied.');
      }

      // Forward the WebView's cookies + UA so the server accepts the request.
      final cookies =
          await CookieManager.instance().getCookies(url: uri);
      final headers = <String, String>{
        if (userAgent != null && userAgent.isNotEmpty)
          'User-Agent': userAgent,
        if (cookies.isNotEmpty)
          'Cookie': cookies.map((c) => '${c.name}=${c.value}').join('; '),
      };

      final tmpDir = await getTemporaryDirectory();
      final tmpFile = File('${tmpDir.path}/$fileName');

      final client = http.Client();
      try {
        final request = http.Request('GET', Uri.parse(uri.toString()));
        request.headers.addAll(headers);
        final response = await client.send(request).timeout(
              const Duration(minutes: 10),
            );
        if (response.statusCode != 200) {
          throw _UserVisibleError(
              'Server returned ${response.statusCode}. Try again.');
        }
        final total = response.contentLength ?? 0;
        var received = 0;
        final sink = tmpFile.openWrite();
        await for (final chunk in response.stream) {
          sink.add(chunk);
          received += chunk.length;
          if (total > 0 && mounted) {
            setState(() => _downloadProgress = received / total);
          }
        }
        await sink.flush();
        await sink.close();
      } finally {
        client.close();
      }

      // Hand the file to native code → public Downloads folder.
      await _channel.invokeMethod<String>('saveToDownloads', {
        'path': tmpFile.path,
        'fileName': fileName,
        'mimeType': mimeType ?? 'video/mp4',
      });
      await tmpFile.delete();

      if (!mounted) return;
      setState(() => _downloadProgress = null);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Download complete — saved to Downloads'),
          duration: Duration(seconds: 4),
        ),
      );
    } on _UserVisibleError catch (e) {
      _failDownload(e.message);
    } on TimeoutException {
      _failDownload('Download timed out. Try again.');
    } catch (e) {
      _failDownload('Download failed: $e');
    }
  }

  void _failDownload(String message) {
    if (!mounted) return;
    setState(() => _downloadProgress = null);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 4)),
    );
  }

  // ------------------------------------------------------------------
  // UI
  // ------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) => _onPopInvoked(didPop),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('TikTok Downloader'),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              tooltip: 'Reload',
              onPressed: () => _webViewController?.reload(),
            ),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'about') _showAbout();
              },
              itemBuilder: (context) => const [
                PopupMenuItem(value: 'about', child: Text('About')),
              ],
            ),
          ],
        ),
        body: Stack(
          children: [
            InAppWebView(
              initialUrlRequest: URLRequest(url: WebUri(kSiteUrl)),
              initialSettings: InAppWebViewSettings(
                javaScriptEnabled: true,
                domStorageEnabled: true,
                mediaPlaybackRequiresUserGesture: false,
                useHybridComposition: true,
                allowsInlineMediaPlayback: true,
                // Keep downloads inside the app via our handler below.
              ),
              pullToRefreshController: _pullToRefreshController,
              onWebViewCreated: (controller) {
                _webViewController = controller;
              },
              onLoadStop: (controller, url) async {
                await _pullToRefreshController?.endRefreshing();
              },
              onReceivedError: (controller, request, error) async {
                await _pullToRefreshController?.endRefreshing();
              },
              shouldOverrideUrlLoading:
                  (controller, navigationAction) async {
                final uri = navigationAction.request.url;
                if (uri == null) return NavigationActionPolicy.ALLOW;
                final scheme = uri.scheme.toLowerCase();
                final host = uri.host.toLowerCase();
                // wa.me / WhatsApp / mailto / tel → external apps.
                if (scheme == 'mailto' ||
                    scheme == 'tel' ||
                    scheme == 'sms' ||
                    host.contains('wa.me') ||
                    host.contains('whatsapp.com')) {
                  await _openExternal(uri);
                  return NavigationActionPolicy.CANCEL;
                }
                return NavigationActionPolicy.ALLOW;
              },
              onDownloadStartRequest:
                  (controller, downloadStartRequest) async {
                await _downloadFile(
                  uri: downloadStartRequest.url,
                  mimeType: downloadStartRequest.mimeType,
                  userAgent: downloadStartRequest.userAgent,
                  contentDisposition:
                      downloadStartRequest.contentDisposition,
                );
              },
            ),
            if (_downloadProgress != null)
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: Material(
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '⬇️ Downloading $_downloadLabel',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 13),
                        ),
                        const SizedBox(height: 6),
                        _downloadProgress! < 0
                            ? const LinearProgressIndicator()
                            : LinearProgressIndicator(
                                value: _downloadProgress!.clamp(0.0, 1.0),
                              ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// An error whose message is safe to show directly to the user.
class _UserVisibleError implements Exception {
  final String message;
  const _UserVisibleError(this.message);
}
